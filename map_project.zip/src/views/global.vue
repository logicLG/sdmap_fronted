<script>
  const map=null;
  export default
  {
    map,//地图控件
  }
</script>
