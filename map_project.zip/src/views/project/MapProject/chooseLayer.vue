<template>
    <div>
    </div>
</template>

<script>

    export default {
        name: 'chooseLayer',
        components:{
        },
        data() {
            return {
              addLayers: [],
              submitLayers: []
            }
        },
        computed:{

        },
        methods: {
          submitChoice() {

            let that=this;
            //这里是请求本地数据，需要改成请求服务器的数据
            this.$axios.get('../static/beijin.json').then(
              function(res){
                debugger;
                // console.log(res);
                that.addLayers.push({"label":"beijin"});
                that.$emit("addLayers",that.addLayers,[res]);//传值给LayerManageComponent.vue中
              }).catch(function (err) {
              console.log(err)
            });
            console.log(this.addLayers);
            console.log(this.submitLayers);
          }
        }
    }
</script>
<style>


</style>

