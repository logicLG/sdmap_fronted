<template>
    <div id="map" style="height:100%" ref="rootmap" @click="clickMap($event)"></div>
</template>

<script>

    import "openlayers/dist/ol-debug.js";
    import global from '../../global.vue'

    export default {
        name: 'mapContainer',
        data() {
            return {
                layers: [
                    // new Tile({
                    new ol.layer.Tile({
                        source: new ol.source.OSM(),
                        isBaseLayer: true
                    }),
                ],
                layers2: [],
                gaodeLayer: [
                    new ol.layer.Tile({
                        source: new ol.source.XYZ({
                            url:
                                "http://webrd03.is.autonavi.com/appmaptile?x={x}&y={y}&z={z}&lang=zh_cn&size=1&scale=1&style=8"
                        }),
                        projection: "EPSG:3857",
                    })
                ],
            }
        },
        mounted: function () {
            this.mapInit();
        },
        methods: {
            mapInit() {
                global.map = new ol.Map({
                    layers: this.gaodeLayer,
                    target: 'map',
                    view: new ol.View({
                        center: ol.proj.transform([116.4, 39.9], 'EPSG:4326', 'EPSG:3857'),
                        zoom: 10
                    })
                });
            },
            clickMap(e) {
                var t = ol.proj.transform(global.map.getEventCoordinate(e), 'EPSG:3857', 'EPSG:4326');
                console.log(t);
            }
        }
    }
</script>
<style>
    .ol-overlaycontainer-stopevent {
        position: absolute;
        top: 0px;
        display: none;
    }
</style>

