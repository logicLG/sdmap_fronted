<template>
    <div>
    </div>
</template>

<style>

</style>
<script>


    export default {
        components: {

        },
        name: "setComponent",
        data() {
            return {


            }
        },
        methods: {

        }
    }
</script>
