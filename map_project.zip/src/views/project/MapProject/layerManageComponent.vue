<template>
    <div id="widgetContainer">
        <div style="margin:20px 0">
            <el-button size="small" style="width:90%" @click="showDialog"><i class="el-icon-plus" style="font-weight: 700;color:rgb(45, 140, 240);"></i>
                添加数据
            </el-button>
        </div>
        <chooseLayer :dialogVisible="dialogVisible" ref="chooseLayer" v-on:addLayers="addLayers"></chooseLayer>
        <transition-group>
            <div v-for="(item,index) in numAndVisible" :key="item.id" draggable="true"
                 style="width: 100%;height:80px"
                 @dragstart="handleDragStart($event,item)"
                 @dragover.prevent="headleDragOver($event,item)"
                 @dragenter="handledDragEnter($event,item)"
                 @dragend="handleDragEnd($event,item)">
                <layerWidget
                        :layerIndex=item.id
                        :title="item.title"
                        v-if="item.visible"
                        v-on:deleteWidget="deleteWidget">
                </layerWidget>
            </div>
        </transition-group>
    </div>
</template>

<script>
    import "openlayers/dist/ol-debug.js";
    import layerWidget from './layerWidget.vue';
    import global from '../../global.vue';
    import chooseLayer from './chooseLayer.vue';


    export default {
        name: 'layerManageComponent',
        components: {
            // ElButton,
            layerWidget,
            chooseLayer,
        },
        data() {
            return {
                json: null,
                numAndVisible: [],
                dragging: null,
                dialogVisible: false,
                myJson: null,
            }
        },
        mounted: function () {

        },
        methods: {
            showDialog() {
              this.$refs.chooseLayer.submitChoice();
            },
            handleDragStart(e, item) {
                this.dragging = item;
            },
            handleDragEnd(e, item) {
                this.dragging = null;
            },
            headleDragOver(e) {
                e.dataTransfer.effectAllowed = "move"
            },
            handledDragEnter(e, item) {
                e.dataTransfer.effectAllowed = "move";
                if (item == this.dragging) {
                    return
                }
                const newitem = [...this.numAndVisible];
                console.log(newitem);
                const src = newitem.indexOf(this.dragging)
                const dst = newitem.indexOf(item);
                let layerSrc = newitem[src].id;
                let layerDes = newitem[dst].id;
                newitem.splice(dst, 0, ...newitem.splice(src, 1));
                this.numAndVisible = newitem;

                let zIndexSrc = 0;
                let zIndexDes = 0;
                //处理图层
                global.map.getLayers().forEach(function (layer, i) {
                    if (i == layerSrc) {
                        zIndexSrc = layer.getZIndex();
                    }
                    if (i == layerDes) {
                        zIndexDes = layer.getZIndex();
                    }
                })
                global.map.getLayers().forEach(function (layer, i) {
                    if (i == layerSrc) {
                        layer.setZIndex(zIndexDes);
                    }
                    if (i == layerDes) {
                        layer.setZIndex(zIndexSrc);
                    }
                })

            },
            addLayers(data,json) {
                this.json = json;
                // let that=this;
              debugger;
                let projection3857 = ol.proj.get('EPSG:3857');
                for (let i = 0; i < data.length; i++) {
                    // let jsonFile=require(data[i].path);
                    // let id = this.getLayerCount() + 1;
                    let id = this.getLayerCount();
                    let layer = new ol.layer.Vector({
                        title: 'add Layer',
                        source: new ol.source.Vector({
                            features: (new ol.format.GeoJSON()).readFeatures(json[i], {
                                dataProjection: 'EPSG:4326',    // 设定JSON数据使用的坐标系
                                featureProjection: 'EPSG:3857' // 设定当前地图使用的feature的坐标系
                            }),
                            // projection:projection3857
                        }),
                        zIndex: id
                    });
                    global.map.addLayer(layer);
                    debugger;
                    let info = {id: id, visible: true, title: data[i].label};
                    this.numAndVisible.push(info);
                }
            },
            getLayerCount() {
                let count = 0;
                global.map.getLayers().forEach(function (layer, i) {
                    count++;
                });
                return count;
            },
            deleteWidget(data) {
                this.numAndVisible[data].visible = false;//把删除图层所对应的控件也删除，即把v-if设为false
                let newNumAndVisible = [];//把删除的图层所对应的控件记录清除
                let length = this.numAndVisible.length;
                for (var i = 0; i < length; i++) {
                    var item = this.numAndVisible[i];
                    if (item.visible == true) {
                        newNumAndVisible.push(item);
                    }
                }
                this.numAndVisible = newNumAndVisible;
            }
        }

    }
</script>
<style>
    layerWidget {
        margin: 10px;
    }
    #widgetContainer{
        text-align: center;
    }
</style>
