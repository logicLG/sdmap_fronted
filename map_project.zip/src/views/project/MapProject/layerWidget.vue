<template>
    <div>
        <div>
            <div style="float:left;margin-left: 5%">
                <el-switch
                        v-model="layer1_visible"
                        :active-text="title"
                        @change="changeSwitch">
                </el-switch>
            </div>
            <div style="float: right;margin-right: 6%">
                <i class="el-icon-location icon" @click="setCenter()"></i>
                <i class="el-icon-delete icon" @click="deleteLayer()"></i>
            </div>
        </div>
        <div>
            <table style="width: 90%;table-layout:fixed;margin-left: 5%" align="left">
                <tr>
                    <td>
                        透明度
                    </td>
                    <td>
                        <el-slider
                                v-model="layer1_opacity"
                                style="width: 100%"
                                @change="changeSlider"
                                :format-tooltip="formatTooltip">
                        </el-slider>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</template>

<script>

    import "openlayers/dist/ol-debug.js";
    import global from '../../global.vue';


    export default {
        name: 'layerWidget',
        props: ['layerIndex', 'title', 'json'],
        data() {
            return {
                layer1_visible: true,
                layer1_opacity: 100,
                myJson: null
            }
        },
        methods: {
            changeSwitch() {
                let that = this;
                global.map.getLayers().forEach(function (layer, i) {
                    // console.log(i)
                    if (i == that.layerIndex) {
                        layer.setVisible(that.layer1_visible);
                    }
                })
            },
            changeSlider() {
                let that = this;
                global.map.getLayers().forEach(function (layer, i) {
                    if (i == that.layerIndex) {
                        // layer.setOpacity(1 - that.layer1_opacity / 100);
                        layer.setOpacity(that.layer1_opacity / 100);
                    }
                })
            },
            formatTooltip(val) {
                return val / 100;
            },
            deleteLayer() {
                let that = this;
                global.map.getLayers().forEach(function (layer, i) {
                    if (i == that.layerIndex) {
                        global.map.removeLayer(layer);
                    }
                });

                this.$emit("deleteWidget", this.layerIndex - 1);
            },
            setCenter() {
                let center = ol.proj.fromLonLat([121.55, 29.88]);
                global.map.getView().setCenter(center);  //设置当前地图的显示中心位置
                global.map.getView().setZoom(19);
            }

        },
        created() {

        },
    }
</script>
<style>
    .icon {
        font-size: 20px;
    }
</style>

