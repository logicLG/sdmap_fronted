<template>
    <span style="z-index: 11">
    <div class="left col " :class="{ collapse1: true }">
          <div class="header row " style="text-align: center;height:50px" :style="{width: 64}">
                <img class="uuLogoYuan" src="../../../assets/uulogoyuan.png"
                     style="height:40px;width:40px;margin-top: 5px" alt="avatar">
          </div>
          <div class="body row scroll-y" style="top:50px">
            <mysidebar v-on:getTools="openToolbar"></mysidebar>
          </div>
    </div>

    <div class="middle col" v-if="!isCollapse">
          <myMid v-on:closeMid="closeToolbar" v-bind:componentName="ComponentName" v-bind:title="title"></myMid>
    </div>

    <div class="right col body" :style="{left: isCollapse?'64px':'320px'}">
          <div class="scroll-y" style="height: 100%">
                <mapContainer></mapContainer>
          </div>
    </div>
  </span>
</template>

<script>
    import mysidebar from './mysidebar.vue'
    import myMid from './mid.vue'
    import mapContainer from './mapContainer.vue'

    export default {
        name: "mapProject",
        components: {
            mysidebar,
            myMid,
            mapContainer
        },
        data() {
            return {
                isCollapse: true,
                ComponentName: "DataComponent",
                title: "板块管理",
                zoom: 2,
                center: [0, 0],
                rotation: 0,
            }
        },
        methods: {
            openToolbar(Names) {
                if (Names.menuName != 'saveComponent' && Names.menuName != 'deleteComponent') {
                    this.ComponentName = Names.menuName;
                    this.title = Names.title;
                    this.isCollapse = false;
                }
            },
            closeToolbar(collapse) {
                this.isCollapse = collapse
            }
        }
    }
</script>

<style>
    @import '../../layout/css/layout.css';
    @import "../../../style/dark.theme.css";

    html, body {
        overflow: hidden;
    }
    .el-header {
        background-color: #B3C0D1;
        color: #333;
        line-height: 60px;
    }

    .el-aside {
        color: #333;
    }

    .left.col .body {
        background: #464c5b;
    }
</style>
