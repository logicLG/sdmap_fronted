<template>
    <div id="myMid">
        <el-row style="top:4px">
            <el-col :span="12">
                <div style="float: left;margin: 5px ;font-size: 14px">{{title}}</div>
            </el-col>
            <el-col :span="12">
                <div style="float: right;margin: 5px">
                    <i class="el-icon-close mypointer" @click="close"></i>
                </div>
            </el-col>
        </el-row>
        <hr style="margin: 5px;height:1px;border:none;border-top:1px solid #DCDFE6;"/>
        <component :is="componentName" style="margin: 3px"></component>

    </div>
</template>
<script>
  import dataComponent from "./layerManageComponent.vue"
    import setComponent from "./setComponent.vue"

    export default {
        props: ['componentName', 'title'],
        name: 'myMid',
        components: {
            setComponent,
          dataComponent
        },
        data() {
            return {}
        },
        watch: {},
        methods: {
            close() {
                this.$emit("closeMid", true)
            },
        }
    }
</script>
<style>
    @import "../../layout/css/layout.css";

    #mytitle {
        position: absolute;
        width: 100%;
        height: 52px;
        background-color: rgb(198, 47, 47);
        -webkit-app-region: drag;
    }
</style>
