<template>
    <div>
      <span id="sidebar">
        <el-menu
                class="disabled-animation"
                text-color="#C8C8C8"
                active-text-color="#2d8cf0"
                background-color="#464c5b"
                @select="open"
                :collapse="true"
                :class="{'hide-sidebard-text': true}">
          <template v-for="item in data">
           <el-menu-item :index="item.id" :name="item.title" :id="item.id" :key="item.id">
              <i :class="item.icon==''? 'el-icon-edit':item.icon" style="text-align: center"></i>
              <span slot="title">{{item.title}}</span>
            </el-menu-item>
           </template>
        </el-menu>
      </span>
    </div>
</template>

<script>

    export default {
       name: 'mysidebar',
        data() {
            return {
                isCollapse: true,
                data: [
                    {
                        id: "dataComponent",
                        title: "数据",
                        icon: "el-icon-location"
                    },
                    {
                        id: "setComponent",
                        title: "设置",
                        icon: "el-icon-setting"
                    }
                ]
            }
        },
        methods: {
            open(menuName, path) {
                var title = document.getElementById(menuName).getAttribute("name")
                var submit = {
                    menuName: menuName,
                    title: title
                };
                this.$emit("getTools", submit);

            }
        }
    }
</script>

<style>
    .el-menu-vertical-demo:not(.el-menu--collapse) {
        width: 200px;
        min-height: 800px;
    }
</style>
