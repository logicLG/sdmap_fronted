import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import mapProject from '../views/project/MapProject/mapProject.vue'

Vue.use(Router)

export const routerOther={
  path:'*',
  redirect:'/map',
};
export const mapRouter = {
  path: '/map',
  name: 'Map project',
  meta: {
    title: '地图工程'
  },
  component: mapProject,
  children: []
};
export const routers=[

    mapRouter,
    routerOther

]
