<template>
    <div>
        <el-dialog :visible.sync="spatialFieldVisible.v"
                   width="35%"
                   title="空间字段选择"
                   @close="clear"
                   v-dialogDrag>
            <el-row class="firstrow">
                要素类型：
                <el-select
                        v-model="value" style="margin-top:20px;margin-left: 10px;" placeholder="请选择数据类型"
                        @change="changeElement">
                    <el-option
                            v-for="item in elementOptions"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                    </el-option>
                </el-select>
            </el-row>
            <el-row class="secondrow">
                <el-col :span="5" style="margin-top: 20px" v-show="selectElement!==''">空间字段：</el-col>
                <el-col :span="16">
                    <div style="margin-top: 20px" v-show="selectElement=='Point'">
                        <el-row>
                            <span>经度</span>
                            <el-select
                                    v-model="field1" style="margin-left: 5px;width:185px" placeholder="请选择字段">
                                <el-option
                                        v-for="item in fieldOptions"
                                        :key="item.field"
                                        :label="item.field"
                                        :value="item.field">
                                </el-option>
                            </el-select>
                        </el-row>
                        <el-row>
                            <span>纬度</span>
                            <el-select
                                    v-model="field2" style="margin-top:15px;margin-left: 5px;width:185px" placeholder="请选择字段">
                                <el-option
                                        v-for="item in fieldOptions"
                                        :key="item.field"
                                        :label="item.field"
                                        :value="item.field">
                                </el-option>
                            </el-select>
                        </el-row>
                    </div>
                    <div style="margin-top: 20px" v-show="selectElement=='LineString'||selectElement=='Polygon'">
                        <span>点序列</span>
                        <el-select
                                v-model="field1" style="margin-left: 5px;width:172px" placeholder="请选择字段">
                            <el-option
                                    v-for="item in fieldOptions"
                                    :key="item.field"
                                    :label="item.field"
                                    :value="item.field">
                            </el-option>
                        </el-select>
                    </div>
                    <div style="margin-top: 20px" v-show="selectElement=='OdPair'">
                        <el-row>
                            <span>起始点经度</span>
                            <el-select
                                    v-model="field1" style="margin-left: 5px;width:172px"  placeholder="请选择字段">
                                <el-option
                                        v-for="item in fieldOptions"
                                        :key="item.field"
                                        :label="item.field"
                                        :value="item.field">
                                </el-option>
                            </el-select>
                        </el-row>
                        <el-row>
                            <span>起始点纬度</span>
                            <el-select
                                    v-model="field2" style="margin-top:15px;margin-left: 5px;width:172px" placeholder="请选择字段">
                                <el-option
                                        v-for="item in fieldOptions"
                                        :key="item.field"
                                        :label="item.field"
                                        :value="item.field">
                                </el-option>
                            </el-select>
                        </el-row>
                        <el-row>
                            <span>结束点经度</span>
                            <el-select
                                    v-model="field3" style="margin-top:15px;margin-left: 5px;width:172px" placeholder="请选择字段">
                                <el-option
                                        v-for="item in fieldOptions"
                                        :key="item.field"
                                        :label="item.field"
                                        :value="item.field">
                                </el-option>
                            </el-select>
                        </el-row>
                        <el-row>
                            <span>结束点纬度</span>
                            <el-select
                                    v-model="field4" style="margin-top:15px;margin-left:5px;width:172px" placeholder="请选择字段">
                                <el-option
                                        v-for="item in fieldOptions"
                                        :key="item.field"
                                        :label="item.field"
                                        :value="item.field">
                                </el-option>
                            </el-select>
                        </el-row>
                    </div>
                </el-col>
            </el-row>
          <el-button type="primary" style="margin-left:20%;margin-top: 20px" @click="showMap">确定</el-button>
          <el-button style="margin-left:20px" @click="cancel">取消</el-button>
        </el-dialog>
    </div>
</template>

<script>
    export default {
        name: "spatialFieldSelect",
        props: {
            // card: {type: Object, default: []}
        },
        data(){
            return{
                dataState:'',
                dataName:'',
                page:'',
                fieldsMap:{},
                field1:'',
                field2:'',
                field3:'',
                field4:'',
                personal:false,
                dataId:'',
                fieldOptions:[],
                value:'',
                selectElement:'',
                elementOptions: [
                    {value:'Point',label:'点要素'},
                    {value:'LineString',label:'线要素'},
                    {value:'Polygon',label:'面要素'},
                    {value:'OdPair',label:'OD流要素'},
                ],
                spatialFieldVisible:Object,
                cardData:{},
            }
        },
        methods:{
            clear(){
                this.value='';
                this.field1='';
                this.field2='';
                this.field3='';
                this.field4='';
            },
            changeElement(val){
                this.selectElement=val;
                this.field1='';
                this.field2='';
                this.field3='';
                this.field4='';
                this.showField();
            },
            //显示数据字段
            showField() {
                let that=this;
                if (this.personal) {
                    let fieldList = [];
                    this.$axios.get("user/data/field/" + this.dataId)
                        .then(function (res) {
                            // console.log(res);
                            let resultList = res.body;
                            for (let listData of resultList) {
                                if (listData !== null) {
                                    let option = {};
                                    option.field = Object.keys(listData)[0];
                                    // option.fieldName = Object.keys(listData)[0];
                                    fieldList.push(option);
                                }
                            }
                            that.fieldOptions=fieldList;
                        }).catch(function (err) {
                        console.log(err);
                    })
                } else {
                    // this.$method.getField(this.dataId,this.showFieldCallback);
                    let fieldList = [];
                    this.$axios.get("/data/field/" + this.dataId)
                        .then(function (res) {
                            // console.log(res);
                            let resultList = res.body;
                            for (let listData of resultList) {
                                if (listData !== null) {
                                    let option = {};
                                    option.field = Object.keys(listData)[0];
                                    // option.fieldName = Object.keys(listData)[0];
                                    fieldList.push(option);
                                }
                            }
                            that.fieldOptions=fieldList;
                        }).catch(function (err) {
                        console.log(err);
                    })
                }
            },
            showFieldCallback(res) {
                this.fieldOptions = res;
                // console.log(this.fieldOptions)
            },
            cancel(){
                this.spatialFieldVisible.v = false;
            },
            //数据上图
            showMap(){
                this.spatialFieldVisible.v=false;
                let that=this;
                if(this.value=='Point'){
                    this.fieldsMap={"lon":this.field1,"lat":this.field2};
                }
                else if(this.value=='LineString'||this.value=='Polygon'){
                    this.fieldsMap={"cors":this.field1};
                }
                else {
                    this.fieldsMap={"start_lon":this.field1,"start_lat":this.field2,"end_lon":this.field3,"end_lat":this.field4}
                }
                // 底图
                this.$Bus.$emit("opengd",true);
                //dataSource页面
                if(this.page=='dataSource'){
                    //个人数据
                    if(this.personal){
                        // mapDialog
                        this.$Bus.$emit("mapDialogParams", {
                            title: this.cardData.id,
                            visible: true,
                            // queryUrl: that.$URL.previewUserDataUrl + this.cardData.id + "/geojson",
                            queryUrl: that.$URL.previewUserDataUrl + "geojsonWithOptionalFields",
                            queryParams: {
                                size: 200,//TODO:需要设置分页,注意offset要乘以size
                                dataId:this.cardData.id,
                                featureType:that.value,
                                fieldsMap:that.fieldsMap,
                            },
                        });
                    }
                    //公共数据
                    else {
                        // mapDialog
                        this.$Bus.$emit("mapDialogParams", {
                            title: this.cardData.meta_name,
                            visible: true,
                            // queryUrl: that.$URL.previewPublicDataUrl + this.cardData.pk_meta_id + "/geojson",
                            queryUrl: that.$URL.previewPublicDataUrl + "geojsonWithOptionalFields",
                            queryParams: {
                                offset: 0,
                                size: 200,//TODO:需要设置分页,注意offset要乘以size
                                dataId:this.cardData.pk_meta_id,
                                featureType:that.value,
                                fieldsMap:that.fieldsMap,
                            },
                        });
                    }
                }
                //gee页面
                else if(this.page=='gee'){
                    if(this.personal){
                        this.$Bus.$emit("dataOnMap",{
                            queryUrl: that.$URL.previewUserDataUrl + "geojsonWithOptionalFields",
                            queryParams: {
                                size: 200,//TODO:需要设置分页,注意offset要乘以size
                                dataId:this.cardData.id,
                                featureType:that.value,
                                fieldsMap:that.fieldsMap,
                            },
                        })
                    }
                    else{
                        this.$Bus.$emit("dataOnMap",{
                            queryUrl: that.$URL.previewPublicDataUrl + "geojsonWithOptionalFields",
                            queryParams: {
                                offset: 0,
                                size: 200,//TODO:需要设置分页,注意offset要乘以size
                                dataId:this.cardData.pk_meta_id,
                                featureType:that.value,
                                fieldsMap:that.fieldsMap,
                            },
                        });
                        let fieldDataParam = {};
                        fieldDataParam.dataId = this.cardData.pk_meta_id;
                        fieldDataParam.dataName = this.cardData.dataName;
                        // fieldDataParam.fields=this.fieldsMap;
                        if (this.field3) {
                            fieldDataParam.fields = this.field1 + ',' + this.field2 + ',' + this.field3 + ',' + this.field4;
                        }
                        else if (this.field2) {
                            fieldDataParam.fields = this.field1 + ',' + this.field2
                        }
                        else {
                            fieldDataParam.fields = this.field1
                        }
                        this.$emit('fieldDataParam', fieldDataParam)
                    }
                }
                //地图工程页面
                else if(this.page=='chooseLayer'){
                    let layer={};
                    layer.label=this.dataName;
                    if(this.field3){
                        layer.field=this.field1+','+this.field2+','+this.field3+','+this.field4;
                    }
                    else if(this.field2){
                        layer.field=this.field1+','+this.field2
                    }
                    else{
                        layer.field=this.field1
                    }
                    layer.featureType=this.value;
                    // console.log(layer);
                    this.$Bus.$emit('layer',layer);//chooseLayer

                    let submitLayer={};
                    submitLayer.type=this.dataState;
                    submitLayer.dataId=this.dataId;
                    submitLayer.size=200;
                    submitLayer.featureType=this.value;
                    submitLayer.fieldsMap=this.fieldsMap;
                    if(this.dataState=='Public'){
                        submitLayer.offset=0;
                    }
                    this.$Bus.$emit('submitLayer',submitLayer);//chooseLayer
                }
            }
        },
        mounted(){

        },
        created(){
            let that=this;
            this.$Bus.$on("fieldSelect",(spatialFieldVisible,cardData,page) =>{
                that.spatialFieldVisible=spatialFieldVisible;
                that.cardData=cardData;
                // console.log(that.cardData);
                // that.personal = !!cardData.userId;
                that.personal = !!cardData.id;
                if(that.personal){
                    that.dataId=cardData.id
                }
                else{
                    that.dataId=cardData.pk_meta_id;
                }
                that.page=page;
                // console.log(that.dataId)
            });
            // this.$Bus.$on("geeFieldSelect",(spatialFieldVisible,cardData) =>{
            //     that.spatialFieldVisible=spatialFieldVisible;
            //     that.cardData=cardData;
            //     console.log(that.cardData);
            //     that.personal = !!cardData.userId;
            //     if(that.personal){
            //         that.dataId=cardData.id
            //     }
            //     else{
            //         that.dataId=cardData.pk_meta_id;
            //     }
            // });
            this.$Bus.$on("fieldSelect2",(spatialFieldVisible,cardData,page) =>{
                that.spatialFieldVisible=spatialFieldVisible;
                that.dataId=cardData.dataid;
                that.dataName=cardData.label;
                that.dataState=cardData.state;
                that.personal=(cardData.state=='Private')?true:false;
                that.page=page;
            });

        }
    }
</script>

<style scoped>

</style>